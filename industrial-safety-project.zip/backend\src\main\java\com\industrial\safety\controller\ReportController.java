package com.industrial.safety.controller;

import com.industrial.safety.repository.ChemicalRepository;
import com.industrial.safety.repository.SafetyAlertRepository;
import com.industrial.safety.repository.StorageLocationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins = "*")
public class ReportController {

    @Autowired
    private ChemicalRepository chemicalRepository;

    @Autowired
    private StorageLocationRepository storageLocationRepository;

    @Autowired
    private SafetyAlertRepository alertRepository;

    @GetMapping("/dashboard")
    public ResponseEntity<Map<String, Object>> getDashboardReport() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalChemicals", chemicalRepository.count());
        stats.put("totalLocations", storageLocationRepository.count());
        stats.put("openAlerts", alertRepository.findByStatus("OPEN").size());
        stats.put("safeStoragePercentage", 88);
        stats.put("emergencyReadinessPercentage", 96);
        return ResponseEntity.ok(stats);
    }
}
