package com.industrial.safety.config;

import com.industrial.safety.model.*;
import com.industrial.safety.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired private UserRepository userRepository;
    @Autowired private ChemicalRepository chemicalRepository;
    @Autowired private StorageLocationRepository storageLocationRepository;
    @Autowired private SafetyAlertRepository alertRepository;
    @Autowired private InspectionRepository inspectionRepository;
    @Autowired private IncidentRepository incidentRepository;
    @Autowired private PpeRepository ppeRepository;
    @Autowired private DocumentRepository documentRepository;
    @Autowired private AuditLogRepository auditLogRepository;
    @Autowired private EmergencyContactRepository emergencyContactRepository;
    @Autowired private CompatibilityRuleRepository compatibilityRuleRepository;
    @Autowired private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        if (userRepository.count() == 0) {
            seedUsers();
            seedStorageLocations();
            seedChemicals();
            seedCompatibilityRules();
            seedAlerts();
            seedInspections();
            seedIncidents();
            seedPpe();
            seedDocuments();
            seedEmergencyContacts();
            seedAuditLogs();
            System.out.println(">>> INDUSTRIAL CHEMICAL SAFETY DATABASE INITIALIZED WITH REALISTIC SEED DATA <<<");
        }
    }

    private void seedUsers() {
        String defaultPass = passwordEncoder.encode("Password123!");
        userRepository.saveAll(List.of(
            new User("EMP-1001", "Dr. Sarah Jenkins", "admin@plant-safety.com", defaultPass, "EHS & Plant Safety Management", User.Role.ADMIN, "ACTIVE"),
            new User("EMP-1002", "Marcus Vance", "safety@plant-safety.com", defaultPass, "Hazardous Materials Control", User.Role.SAFETY_OFFICER, "ACTIVE"),
            new User("EMP-1003", "Robert Sterling", "warehouse@plant-safety.com", defaultPass, "Chemical Storage & Logistics", User.Role.WAREHOUSE_MANAGER, "ACTIVE"),
            new User("EMP-1004", "Elena Rostova", "operator@plant-safety.com", defaultPass, "Process Operations", User.Role.EMPLOYEE, "ACTIVE")
        ));
    }

    private void seedStorageLocations() {
        StorageLocation loc1 = new StorageLocation();
        loc1.setLocationId("LOC-W1-FLAM");
        loc1.setName("Flammable Storage Room");
        loc1.setType("Vault Storage");
        loc1.setMaxCapacity(5000.0);
        loc1.setCurrentCapacity(3600.0);
        loc1.setCapacityPercentage(72);
        loc1.setTemperature(18.5);
        loc1.setTargetTempRange("15.0 - 20.0 °C");
        loc1.setHumidity(45);
        loc1.setVentilationStatus("OPERATIONAL");
        loc1.setFireProtectionStatus("ACTIVE");
        loc1.setInspectionStatus("COMPLIANT");
        loc1.setRiskStatus("SAFE");
        loc1.setZone("FLAMMABLE");
        loc1.setSupervisor("Robert Sterling");

        StorageLocation loc2 = new StorageLocation();
        loc2.setLocationId("LOC-W1-ACID");
        loc2.setName("Acid Storage Area");
        loc2.setType("Containment Cell");
        loc2.setMaxCapacity(3000.0);
        loc2.setCurrentCapacity(2820.0);
        loc2.setCapacityPercentage(94);
        loc2.setTemperature(21.0);
        loc2.setTargetTempRange("18.0 - 24.0 °C");
        loc2.setHumidity(52);
        loc2.setVentilationStatus("OPERATIONAL");
        loc2.setFireProtectionStatus("ACTIVE");
        loc2.setInspectionStatus("DUE_SOON");
        loc2.setRiskStatus("HIGH");
        loc2.setZone("ACID");
        loc2.setSupervisor("Robert Sterling");

        storageLocationRepository.saveAll(List.of(loc1, loc2));
    }

    private void seedChemicals() {
        Chemical chem1 = new Chemical();
        chem1.setChemicalId("CHEM-1001");
        chem1.setName("Hydrochloric Acid 37%");
        chem1.setCasNumber("7647-01-0");
        chem1.setManufacturer("Sigma-Aldrich Chemical Corp");
        chem1.setCategory("Acids & Corrosives");
        chem1.setHazardClass("CORROSIVE_ACID");
        chem1.setUnNumber("UN1789");
        chem1.setQuantity(1450.0);
        chem1.setUnit("L");
        chem1.setMaxStorageQuantity(1500.0);
        chem1.setStorageLocationId(2L);
        chem1.setStorageLocationName("Acid Storage Area");
        chem1.setStorageTemperature("15-25°C");
        chem1.setExpiryDate("2026-10-15");
        chem1.setBatchNumber("HA-2025-091A");
        chem1.setEmergencyContact("Chemtrec 1-800-424-9300");
        chem1.setRiskLevel("HIGH");
        chem1.setStatus("OPTIMAL");
        chem1.setSignalWord("DANGER");
        chem1.setHazardStatements("H314: Causes severe skin burns and eye damage.");
        chem1.setPrecautionaryStatements("P280: Wear protective gloves and eye protection.");
        chem1.setRequiredVentilation("Continuous mechanical exhaust.");
        chem1.setFireResponse("Use water spray or fog.");
        chem1.setSpillResponse("Neutralize small spills with sodium bicarbonate.");
        chem1.setFirstAid("Flush skin and eyes under emergency wash for 15+ minutes.");

        Chemical chem2 = new Chemical();
        chem2.setChemicalId("CHEM-1004");
        chem2.setName("Acetone ACS Grade");
        chem2.setCasNumber("67-64-1");
        chem2.setManufacturer("Thermo Fisher Scientific");
        chem2.setCategory("Organic Solvents");
        chem2.setHazardClass("FLAMMABLE_LIQUID");
        chem2.setUnNumber("UN1090");
        chem2.setQuantity(1800.0);
        chem2.setUnit("L");
        chem2.setMaxStorageQuantity(2500.0);
        chem2.setStorageLocationId(1L);
        chem2.setStorageLocationName("Flammable Storage Room");
        chem2.setStorageTemperature("15-20°C");
        chem2.setExpiryDate("2026-09-10");
        chem2.setBatchNumber("ACT-2024-X99");
        chem2.setEmergencyContact("Fire Safety Desk x4402");
        chem2.setRiskLevel("HIGH");
        chem2.setStatus("EXPIRED");
        chem2.setSignalWord("DANGER");
        chem2.setHazardStatements("H225: Highly flammable liquid and vapour.");
        chem2.setPrecautionaryStatements("P210: Keep away from sparks and flames.");
        chem2.setRequiredVentilation("Explosion-proof exhaust.");
        chem2.setFireResponse("Alcohol-resistant foam, dry chemical, CO2.");
        chem2.setSpillResponse("Eliminate ignition sources. Absorb with non-combustible material.");
        chem2.setFirstAid("Remove to fresh air.");

        chemicalRepository.saveAll(List.of(chem1, chem2));
    }

    private void seedCompatibilityRules() {
        CompatibilityRule rule1 = new CompatibilityRule();
        rule1.setHazardClassA("CORROSIVE_ACID");
        rule1.setHazardClassB("CORROSIVE_BASE");
        rule1.setCompatible(false);
        rule1.setRiskLevel("CRITICAL");
        rule1.setReason("Mixing acids and bases triggers violent exothermic boiling and toxic chemical spattering.");
        rule1.setRecommendedAction("Store separately in dedicated containment cells.");

        compatibilityRuleRepository.save(rule1);
    }

    private void seedAlerts() {
        SafetyAlert alt1 = new SafetyAlert();
        alt1.setAlertId("ALT-2026-0891");
        alt1.setDate("2026-09-26");
        alt1.setTime("08:15 AM");
        alt1.setLocation("Chemical Warehouse B");
        alt1.setChemical("General Inventory");
        alt1.setAlertType("STORAGE_OVERCAPACITY");
        alt1.setRiskLevel("CRITICAL");
        alt1.setDescription("Storage area capacity reached 98.1%.");
        alt1.setStatus("OPEN");
        alt1.setIsCritical(true);

        alertRepository.save(alt1);
    }

    private void seedInspections() {
        SafetyInspection insp1 = new SafetyInspection();
        insp1.setInspectionId("INS-2026-042");
        insp1.setInspector("Marcus Vance");
        insp1.setLocationId("LOC-W1-FLAM");
        insp1.setLocationName("Flammable Storage Room");
        insp1.setDate("2026-09-20");
        insp1.setDueDate("2026-09-27");
        insp1.setInspectionType("ROUTINE_WEEKLY");
        insp1.setFindings("Expired container detected.");
        insp1.setCorrectiveAction("Transfer to quarantine cabinet.");
        insp1.setCompliancePercentage(90);
        insp1.setStatus("COMPLETED");

        inspectionRepository.save(insp1);
    }

    private void seedIncidents() {
        Incident inc1 = new Incident();
        inc1.setIncidentId("INC-2026-009");
        inc1.setDate("2026-09-21");
        inc1.setTime("14:20");
        inc1.setLocation("Solvent Storage Area");
        inc1.setChemicalInvolved("Ethanol Absolute");
        inc1.setIncidentType("CHEMICAL_SPILL");
        inc1.setSeverity("MEDIUM");
        inc1.setDescription("Flange drip resulting in 2.5L spilled.");
        inc1.setImmediateAction("Spill kit applied.");
        inc1.setReportedBy("Elena Rostova");
        inc1.setStatus("CLOSED");

        incidentRepository.save(inc1);
    }

    private void seedPpe() {
        PpeItem item1 = new PpeItem();
        item1.setType("GLOVES");
        item1.setName("Heavy Duty Nitrile Chemical Gloves");
        item1.setQuantity(140);
        item1.setMinThreshold(50);
        item1.setStorageLocation("Central PPE Cabinet A1");
        item1.setIssueDate("2026-01-10");
        item1.setExpiryDate("2028-01-10");
        item1.setAvailableQuantity(110);
        item1.setStatus("OPTIMAL");

        ppeRepository.save(item1);
    }

    private void seedDocuments() {
        SafetyDocument doc1 = new SafetyDocument();
        doc1.setTitle("Safety Data Sheet - Hydrochloric Acid 37%");
        doc1.setCategory("SAFETY_DATA_SHEET");
        doc1.setChemicalName("Hydrochloric Acid 37%");
        doc1.setCasNumber("7647-01-0");
        doc1.setUploadDate("2026-01-15");
        doc1.setExpiryDate("2029-01-15");
        doc1.setFileSize("482 KB");
        doc1.setFileType("PDF");
        doc1.setUploadedBy("Dr. Sarah Jenkins");
        doc1.setUrl("#");
        doc1.setVersion("v4.2");

        documentRepository.save(doc1);
    }

    private void seedEmergencyContacts() {
        EmergencyContact contact1 = new EmergencyContact();
        contact1.setRoleTitle("Industrial Fire Department Dispatch");
        contact1.setName("Metro Industrial Fire & Rescue");
        contact1.setPhone("911 / (555) 911-3473");
        contact1.setEmail("dispatch@metrofire.gov");
        contact1.setLocation("Station 14 (1.2 km away)");
        contact1.setAvailability("24 / 7 / 365");
        contact1.setIsPrimary(true);

        emergencyContactRepository.save(contact1);
    }

    private void seedAuditLogs() {
        auditLogRepository.save(new AuditLogEntry(
            "2026-09-26 09:12:04", "Marcus Vance", "SAFETY_OFFICER", "USER_LOGIN", "Authentication", "USR-002", "User successfully authenticated via JWT role-based security."
        ));
    }
}
