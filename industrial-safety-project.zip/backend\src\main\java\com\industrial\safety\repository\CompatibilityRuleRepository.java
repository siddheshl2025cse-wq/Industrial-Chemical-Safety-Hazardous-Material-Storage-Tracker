package com.industrial.safety.repository;

import com.industrial.safety.model.CompatibilityRule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CompatibilityRuleRepository extends JpaRepository<CompatibilityRule, Long> {
    Optional<CompatibilityRule> findByHazardClassAAndHazardClassB(String hazardClassA, String hazardClassB);
}
