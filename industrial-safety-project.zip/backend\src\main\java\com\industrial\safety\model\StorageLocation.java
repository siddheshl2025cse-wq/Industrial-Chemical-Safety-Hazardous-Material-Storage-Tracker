package com.industrial.safety.model;

import jakarta.persistence.*;

@Entity
@Table(name = "storage_locations")
public class StorageLocation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String locationId;

    @Column(nullable = false)
    private String name;

    private String type;
    private Double maxCapacity;
    private Double currentCapacity;
    private Integer capacityPercentage;

    private Double temperature;
    private String targetTempRange;
    private Integer humidity;

    private String ventilationStatus;
    private String fireProtectionStatus;
    private String inspectionStatus;
    private String riskStatus;
    private String zone;
    private String supervisor;

    public StorageLocation() {}

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getLocationId() { return locationId; }
    public void setLocationId(String locationId) { this.locationId = locationId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public Double getMaxCapacity() { return maxCapacity; }
    public void setMaxCapacity(Double maxCapacity) { this.maxCapacity = maxCapacity; }

    public Double getCurrentCapacity() { return currentCapacity; }
    public void setCurrentCapacity(Double currentCapacity) { this.currentCapacity = currentCapacity; }

    public Integer getCapacityPercentage() { return capacityPercentage; }
    public void setCapacityPercentage(Integer capacityPercentage) { this.capacityPercentage = capacityPercentage; }

    public Double getTemperature() { return temperature; }
    public void setTemperature(Double temperature) { this.temperature = temperature; }

    public String getTargetTempRange() { return targetTempRange; }
    public void setTargetTempRange(String targetTempRange) { this.targetTempRange = targetTempRange; }

    public Integer getHumidity() { return humidity; }
    public void setHumidity(Integer humidity) { this.humidity = humidity; }

    public String getVentilationStatus() { return ventilationStatus; }
    public void setVentilationStatus(String ventilationStatus) { this.ventilationStatus = ventilationStatus; }

    public String getFireProtectionStatus() { return fireProtectionStatus; }
    public void setFireProtectionStatus(String fireProtectionStatus) { this.fireProtectionStatus = fireProtectionStatus; }

    public String getInspectionStatus() { return inspectionStatus; }
    public void setInspectionStatus(String inspectionStatus) { this.inspectionStatus = inspectionStatus; }

    public String getRiskStatus() { return riskStatus; }
    public void setRiskStatus(String riskStatus) { this.riskStatus = riskStatus; }

    public String getZone() { return zone; }
    public void setZone(String zone) { this.zone = zone; }

    public String getSupervisor() { return supervisor; }
    public void setSupervisor(String supervisor) { this.supervisor = supervisor; }
}
