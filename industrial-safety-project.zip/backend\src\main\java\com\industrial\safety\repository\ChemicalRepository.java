package com.industrial.safety.repository;

import com.industrial.safety.model.Chemical;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ChemicalRepository extends JpaRepository<Chemical, Long> {
    Optional<Chemical> findByChemicalId(String chemicalId);
    List<Chemical> findByHazardClass(String hazardClass);
    List<Chemical> findByStorageLocationId(Long storageLocationId);
    List<Chemical> findByStatus(String status);
}
