package com.industrial.safety.model;

import jakarta.persistence.*;

@Entity
@Table(name = "audit_logs")
public class AuditLogEntry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String timestamp;

    private String user;
    private String userRole;
    private String action;
    private String module;
    private String recordId;

    @Column(length = 1000)
    private String description;

    public AuditLogEntry() {}

    public AuditLogEntry(String timestamp, String user, String userRole, String action, String module, String recordId, String description) {
        this.timestamp = timestamp;
        this.user = user;
        this.userRole = userRole;
        this.action = action;
        this.module = module;
        this.recordId = recordId;
        this.description = description;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTimestamp() { return timestamp; }
    public void setTimestamp(String timestamp) { this.timestamp = timestamp; }

    public String getUser() { return user; }
    public void setUser(String user) { this.user = user; }

    public String getUserRole() { return userRole; }
    public void setUserRole(String userRole) { this.userRole = userRole; }

    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }

    public String getModule() { return module; }
    public void setModule(String module) { this.module = module; }

    public String getRecordId() { return recordId; }
    public void setRecordId(String recordId) { this.recordId = recordId; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}
