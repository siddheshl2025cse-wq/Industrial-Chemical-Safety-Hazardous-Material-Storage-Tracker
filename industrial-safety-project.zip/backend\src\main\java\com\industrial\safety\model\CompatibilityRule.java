package com.industrial.safety.model;

import jakarta.persistence.*;

@Entity
@Table(name = "compatibility_rules")
public class CompatibilityRule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String hazardClassA;
    private String hazardClassB;
    private Boolean compatible;
    private String riskLevel;

    @Column(length = 1000)
    private String reason;

    @Column(length = 1000)
    private String recommendedAction;

    public CompatibilityRule() {}

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getHazardClassA() { return hazardClassA; }
    public void setHazardClassA(String hazardClassA) { this.hazardClassA = hazardClassA; }

    public String getHazardClassB() { return hazardClassB; }
    public void setHazardClassB(String hazardClassB) { this.hazardClassB = hazardClassB; }

    public Boolean getCompatible() { return compatible; }
    public void setCompatible(Boolean compatible) { this.compatible = compatible; }

    public String getRiskLevel() { return riskLevel; }
    public void setRiskLevel(String riskLevel) { this.riskLevel = riskLevel; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public String getRecommendedAction() { return recommendedAction; }
    public void setRecommendedAction(String recommendedAction) { this.recommendedAction = recommendedAction; }
}
