package com.industrial.safety.controller;

import com.industrial.safety.model.SafetyInspection;
import com.industrial.safety.repository.InspectionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/inspections")
@CrossOrigin(origins = "*")
public class InspectionController {

    @Autowired
    private InspectionRepository inspectionRepository;

    @GetMapping
    public List<SafetyInspection> getAllInspections() {
        return inspectionRepository.findAll();
    }

    @PostMapping
    public SafetyInspection createInspection(@RequestBody SafetyInspection inspection) {
        if (inspection.getInspectionId() == null) {
            inspection.setInspectionId("INS-2026-" + (100 + (int)(Math.random() * 900)));
        }
        return inspectionRepository.save(inspection);
    }
}
