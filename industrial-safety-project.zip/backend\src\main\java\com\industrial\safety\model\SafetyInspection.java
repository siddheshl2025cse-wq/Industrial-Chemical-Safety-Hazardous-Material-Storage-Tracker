package com.industrial.safety.model;

import jakarta.persistence.*;

@Entity
@Table(name = "inspections")
public class SafetyInspection {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String inspectionId;

    private String inspector;
    private String locationId;
    private String locationName;
    private String date;
    private String dueDate;
    private String inspectionType;

    @Column(length = 1000)
    private String findings;

    @Column(length = 1000)
    private String correctiveAction;

    private Integer compliancePercentage;
    private String status; // SCHEDULED, IN_PROGRESS, COMPLETED, OVERDUE

    public SafetyInspection() {}

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getInspectionId() { return inspectionId; }
    public void setInspectionId(String inspectionId) { this.inspectionId = inspectionId; }

    public String getInspector() { return inspector; }
    public void setInspector(String inspector) { this.inspector = inspector; }

    public String getLocationId() { return locationId; }
    public void setLocationId(String locationId) { this.locationId = locationId; }

    public String getLocationName() { return locationName; }
    public void setLocationName(String locationName) { this.locationName = locationName; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getDueDate() { return dueDate; }
    public void setDueDate(String dueDate) { this.dueDate = dueDate; }

    public String getInspectionType() { return inspectionType; }
    public void setInspectionType(String inspectionType) { this.inspectionType = inspectionType; }

    public String getFindings() { return findings; }
    public void setFindings(String findings) { this.findings = findings; }

    public String getCorrectiveAction() { return correctiveAction; }
    public void setCorrectiveAction(String correctiveAction) { this.correctiveAction = correctiveAction; }

    public Integer getCompliancePercentage() { return compliancePercentage; }
    public void setCompliancePercentage(Integer compliancePercentage) { this.compliancePercentage = compliancePercentage; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
