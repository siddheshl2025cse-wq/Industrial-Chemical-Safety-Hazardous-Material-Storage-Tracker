package com.industrial.safety.repository;

import com.industrial.safety.model.PpeItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PpeRepository extends JpaRepository<PpeItem, Long> {
}
