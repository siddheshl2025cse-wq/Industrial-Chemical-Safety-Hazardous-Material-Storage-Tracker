package com.industrial.safety.model;

import jakarta.persistence.*;

@Entity
@Table(name = "chemicals")
public class Chemical {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String chemicalId; // CHEM-1001

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String casNumber;

    private String manufacturer;
    private String category;
    private String hazardClass;
    private String unNumber;

    private Double quantity;
    private String unit;
    private Double maxStorageQuantity;

    private Long storageLocationId;
    private String storageLocationName;

    private String storageTemperature;
    private String expiryDate;
    private String batchNumber;

    private String emergencyContact;

    @Column(length = 1000)
    private String notes;

    private String riskLevel; // SAFE, LOW, MEDIUM, HIGH, CRITICAL
    private String status;    // OPTIMAL, LOW_STOCK, EXPIRED, EXPIRING_SOON, OVERCAPACITY

    private String signalWord;

    @Column(length = 2000)
    private String hazardStatements;

    @Column(length = 2000)
    private String precautionaryStatements;

    private String requiredVentilation;

    @Column(length = 1000)
    private String storageCompatibility;

    @Column(length = 1000)
    private String fireResponse;

    @Column(length = 1000)
    private String spillResponse;

    @Column(length = 1000)
    private String firstAid;

    public Chemical() {}

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getChemicalId() { return chemicalId; }
    public void setChemicalId(String chemicalId) { this.chemicalId = chemicalId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getCasNumber() { return casNumber; }
    public void setCasNumber(String casNumber) { this.casNumber = casNumber; }

    public String getManufacturer() { return manufacturer; }
    public void setManufacturer(String manufacturer) { this.manufacturer = manufacturer; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getHazardClass() { return hazardClass; }
    public void setHazardClass(String hazardClass) { this.hazardClass = hazardClass; }

    public String getUnNumber() { return unNumber; }
    public void setUnNumber(String unNumber) { this.unNumber = unNumber; }

    public Double getQuantity() { return quantity; }
    public void setQuantity(Double quantity) { this.quantity = quantity; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public Double getMaxStorageQuantity() { return maxStorageQuantity; }
    public void setMaxStorageQuantity(Double maxStorageQuantity) { this.maxStorageQuantity = maxStorageQuantity; }

    public Long getStorageLocationId() { return storageLocationId; }
    public void setStorageLocationId(Long storageLocationId) { this.storageLocationId = storageLocationId; }

    public String getStorageLocationName() { return storageLocationName; }
    public void setStorageLocationName(String storageLocationName) { this.storageLocationName = storageLocationName; }

    public String getStorageTemperature() { return storageTemperature; }
    public void setStorageTemperature(String storageTemperature) { this.storageTemperature = storageTemperature; }

    public String getExpiryDate() { return expiryDate; }
    public void setExpiryDate(String expiryDate) { this.expiryDate = expiryDate; }

    public String getBatchNumber() { return batchNumber; }
    public void setBatchNumber(String batchNumber) { this.batchNumber = batchNumber; }

    public String getEmergencyContact() { return emergencyContact; }
    public void setEmergencyContact(String emergencyContact) { this.emergencyContact = emergencyContact; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public String getRiskLevel() { return riskLevel; }
    public void setRiskLevel(String riskLevel) { this.riskLevel = riskLevel; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getSignalWord() { return signalWord; }
    public void setSignalWord(String signalWord) { this.signalWord = signalWord; }

    public String getHazardStatements() { return hazardStatements; }
    public void setHazardStatements(String hazardStatements) { this.hazardStatements = hazardStatements; }

    public String getPrecautionaryStatements() { return precautionaryStatements; }
    public void setPrecautionaryStatements(String precautionaryStatements) { this.precautionaryStatements = precautionaryStatements; }

    public String getRequiredVentilation() { return requiredVentilation; }
    public void setRequiredVentilation(String requiredVentilation) { this.requiredVentilation = requiredVentilation; }

    public String getStorageCompatibility() { return storageCompatibility; }
    public void setStorageCompatibility(String storageCompatibility) { this.storageCompatibility = storageCompatibility; }

    public String getFireResponse() { return fireResponse; }
    public void setFireResponse(String fireResponse) { this.fireResponse = fireResponse; }

    public String getSpillResponse() { return spillResponse; }
    public void setSpillResponse(String spillResponse) { this.spillResponse = spillResponse; }

    public String getFirstAid() { return firstAid; }
    public void setFirstAid(String firstAid) { this.firstAid = firstAid; }
}
