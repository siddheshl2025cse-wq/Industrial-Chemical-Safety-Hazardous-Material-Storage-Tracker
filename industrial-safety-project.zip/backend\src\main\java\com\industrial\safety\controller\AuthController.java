package com.industrial.safety.controller;

import com.industrial.safety.model.User;
import com.industrial.safety.repository.UserRepository;
import com.industrial.safety.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> credentials) {
        String username = credentials.get("username");
        String password = credentials.get("password");

        if (username == null || username.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Username or Email is required"));
        }

        Optional<User> userOpt = userRepository.findByEmail(username);
        if (userOpt.isEmpty()) {
            userOpt = userRepository.findByEmployeeId(username);
        }

        User user;
        if (userOpt.isPresent()) {
            user = userOpt.get();
        } else {
            // Default fallback for dev/demo if database initializer hasn't finished
            user = new User(username, "Dr. Sarah Jenkins", username, "password", "EHS Safety", User.Role.ADMIN, "ACTIVE");
        }

        String token = jwtUtil.generateToken(user.getEmployeeId(), user.getRole().name());

        Map<String, Object> response = new HashMap<>();
        response.put("token", token);
        response.put("user", user);

        return ResponseEntity.ok(response);
    }
}
