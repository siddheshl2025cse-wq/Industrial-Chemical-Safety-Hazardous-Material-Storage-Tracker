package com.industrial.safety.controller;

import com.industrial.safety.model.SafetyAlert;
import com.industrial.safety.repository.SafetyAlertRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/alerts")
@CrossOrigin(origins = "*")
public class AlertController {

    @Autowired
    private SafetyAlertRepository alertRepository;

    @GetMapping
    public List<SafetyAlert> getAllAlerts() {
        return alertRepository.findAll();
    }

    @PutMapping("/{id}/acknowledge")
    public ResponseEntity<SafetyAlert> acknowledgeAlert(@PathVariable Long id, @RequestBody Map<String, String> body) {
        Optional<SafetyAlert> alertOpt = alertRepository.findById(id);
        if (alertOpt.isPresent()) {
            SafetyAlert alert = alertOpt.get();
            alert.setStatus("ACKNOWLEDGED");
            alert.setAcknowledgedBy(body.getOrDefault("user", "Safety Officer"));
            alert.setAcknowledgedAt(new java.util.Date().toString());
            return ResponseEntity.ok(alertRepository.save(alert));
        }
        return ResponseEntity.notFound().build();
    }

    @PutMapping("/{id}/resolve")
    public ResponseEntity<SafetyAlert> resolveAlert(@PathVariable Long id, @RequestBody Map<String, String> body) {
        Optional<SafetyAlert> alertOpt = alertRepository.findById(id);
        if (alertOpt.isPresent()) {
            SafetyAlert alert = alertOpt.get();
            alert.setStatus("RESOLVED");
            alert.setResolvedBy(body.getOrDefault("user", "Safety Officer"));
            alert.setResolvedAt(new java.util.Date().toString());
            alert.setResolutionNotes(body.getOrDefault("notes", "Resolved safety condition."));
            return ResponseEntity.ok(alertRepository.save(alert));
        }
        return ResponseEntity.notFound().build();
    }
}
