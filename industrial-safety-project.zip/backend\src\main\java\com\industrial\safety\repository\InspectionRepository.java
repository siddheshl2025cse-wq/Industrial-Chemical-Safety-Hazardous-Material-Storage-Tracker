package com.industrial.safety.repository;

import com.industrial.safety.model.SafetyInspection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InspectionRepository extends JpaRepository<SafetyInspection, Long> {
}
