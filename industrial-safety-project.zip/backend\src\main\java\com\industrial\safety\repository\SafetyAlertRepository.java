package com.industrial.safety.repository;

import com.industrial.safety.model.SafetyAlert;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SafetyAlertRepository extends JpaRepository<SafetyAlert, Long> {
    List<SafetyAlert> findByStatus(String status);
    List<SafetyAlert> findByRiskLevel(String riskLevel);
}
