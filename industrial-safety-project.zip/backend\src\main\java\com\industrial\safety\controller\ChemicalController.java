package com.industrial.safety.controller;

import com.industrial.safety.model.Chemical;
import com.industrial.safety.repository.ChemicalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/chemicals")
@CrossOrigin(origins = "*")
public class ChemicalController {

    @Autowired
    private ChemicalRepository chemicalRepository;

    @GetMapping
    public List<Chemical> getAllChemicals() {
        return chemicalRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Chemical> getChemicalById(@PathVariable Long id) {
        Optional<Chemical> chemical = chemicalRepository.findById(id);
        return chemical.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public Chemical createChemical(@RequestBody Chemical chemical) {
        if (chemical.getChemicalId() == null || chemical.getChemicalId().isEmpty()) {
            chemical.setChemicalId("CHEM-" + (1000 + (int)(Math.random() * 9000)));
        }
        return chemicalRepository.save(chemical);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Chemical> updateChemical(@PathVariable Long id, @RequestBody Chemical chemDetails) {
        Optional<Chemical> optionalChemical = chemicalRepository.findById(id);
        if (optionalChemical.isPresent()) {
            Chemical existing = optionalChemical.get();
            existing.setName(chemDetails.getName());
            existing.setCasNumber(chemDetails.getCasNumber());
            existing.setQuantity(chemDetails.getQuantity());
            existing.setStorageLocationName(chemDetails.getStorageLocationName());
            existing.setExpiryDate(chemDetails.getExpiryDate());
            existing.setStatus(chemDetails.getStatus());
            existing.setRiskLevel(chemDetails.getRiskLevel());
            return ResponseEntity.ok(chemicalRepository.save(existing));
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteChemical(@PathVariable Long id) {
        if (chemicalRepository.existsById(id)) {
            chemicalRepository.deleteById(id);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
}
