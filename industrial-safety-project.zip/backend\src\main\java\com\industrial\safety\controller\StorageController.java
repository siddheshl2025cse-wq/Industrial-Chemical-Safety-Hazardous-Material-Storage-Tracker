package com.industrial.safety.controller;

import com.industrial.safety.model.StorageLocation;
import com.industrial.safety.repository.StorageLocationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/storage")
@CrossOrigin(origins = "*")
public class StorageController {

    @Autowired
    private StorageLocationRepository storageLocationRepository;

    @GetMapping
    public List<StorageLocation> getAllStorageLocations() {
        return storageLocationRepository.findAll();
    }

    @PostMapping
    public StorageLocation createStorageLocation(@RequestBody StorageLocation storageLocation) {
        if (storageLocation.getLocationId() == null) {
            storageLocation.setLocationId("LOC-Z" + (10 + (int)(Math.random() * 90)));
        }
        return storageLocationRepository.save(storageLocation);
    }
}
