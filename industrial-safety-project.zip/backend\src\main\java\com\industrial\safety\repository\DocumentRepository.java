package com.industrial.safety.repository;

import com.industrial.safety.model.SafetyDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DocumentRepository extends JpaRepository<SafetyDocument, Long> {
}
