package com.industrial.safety.controller;

import com.industrial.safety.model.AuditLogEntry;
import com.industrial.safety.repository.AuditLogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/audit-logs")
@CrossOrigin(origins = "*")
public class AuditLogController {

    @Autowired
    private AuditLogRepository auditLogRepository;

    @GetMapping
    public List<AuditLogEntry> getAuditLogs() {
        return auditLogRepository.findAllByOrderByIdDesc();
    }
}
