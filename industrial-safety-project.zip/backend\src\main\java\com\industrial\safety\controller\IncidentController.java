package com.industrial.safety.controller;

import com.industrial.safety.model.Incident;
import com.industrial.safety.repository.IncidentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/incidents")
@CrossOrigin(origins = "*")
public class IncidentController {

    @Autowired
    private IncidentRepository incidentRepository;

    @GetMapping
    public List<Incident> getAllIncidents() {
        return incidentRepository.findAll();
    }

    @PostMapping
    public Incident createIncident(@RequestBody Incident incident) {
        if (incident.getIncidentId() == null) {
            incident.setIncidentId("INC-2026-" + (100 + (int)(Math.random() * 900)));
        }
        return incidentRepository.save(incident);
    }
}
